# SmartLeads Frontend (React + TypeScript + Vite)

Frontend UI for the SmartLeads dashboard. Includes authentication flow, protected routes, dashboard pages, and API integration via Axios + React Query.

## Tech Stack

- React + TypeScript
- Vite
- Tailwind CSS (via `@tailwindcss/vite`)
- React Router
- React Query
- Axios
- Zustand
- Zod + React Hook Form

## Folder Structure

```
frontend/
  src/
    api/            # axios client + API wrappers
    components/     # layout + UI components
    hooks/          # react hooks
    pages/          # route pages
    store/          # Zustand stores
    types/          # TS types
    utils/          # helpers
  .env              # local env only
  vite.config.ts
```

## Environment Variables

Local development uses `frontend/.env`:

- `VITE_API_URL=http://localhost:5000/api/v1`

For production (Netlify), set the same variable in Netlify UI:

- `VITE_API_URL=https://<your-backend-domain>/api/v1`

## Install & Run (Local)

From repo root:

```
yarn --cwd frontend install
yarn --cwd frontend dev
```

Lint & build:

```
yarn --cwd frontend lint
yarn --cwd frontend build
```

## Connect to Local Backend

1. Start backend on `http://localhost:5000`
2. Ensure:
   - `frontend/.env`: `VITE_API_URL=http://localhost:5000/api/v1`
   - `backend/.env`: `CLIENT_URL=http://localhost:5173` (use the port Vite prints)
3. Start frontend (Vite default is `http://localhost:5173`)

## Docker (Static Build)

This Docker image builds the Vite app and serves it using Nginx.

Build:

```
docker build -t smartleads-frontend ./frontend
```

Run:

```
docker run --rm -p 8080:80 smartleads-frontend
```

Open:

- `http://localhost:8080`

## Deploy (Netlify)

Recommended Netlify settings:

- Base directory: `frontend`
- Build command: `yarn build`
- Publish directory: `dist`
- Env: `VITE_API_URL=https://<your-backend-domain>/api/v1`

