import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { Zap, Mail, Lock, User } from 'lucide-react';
import { authApi } from '../../api/auth.api';
import { Input } from '../../components/ui/FormFields';
import { Button } from '../../components/ui/Button';
import { UserRole } from '../../types';
import { getErrorMessage } from '../../utils/helpers';

const schema = z.object({
  name:     z.string().min(2, 'Min 2 characters').max(100),
  email:    z.string().email('Invalid email'),
  password: z.string()
    .min(8, 'Min 8 characters')
    .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, 'Must contain uppercase, lowercase, and number'),
  role: z.nativeEnum(UserRole).optional(),
});
type FormData = z.infer<typeof schema>;

const SignupPage: React.FC = () => {
  const navigate = useNavigate();

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { role: UserRole.SALES },
  });

  const mutation = useMutation({
    mutationFn: (data: FormData) => authApi.signup(data).then((r) => r.data),
    onSuccess: (_res, variables) => {
      toast.success('Account created! Please check your email to verify.');
      navigate(`/verify-email?email=${encodeURIComponent(variables.email)}`);
    },
    onError: (err) => toast.error(getErrorMessage(err)),
  });

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0f1117] p-4">
      <div className="absolute inset-0 opacity-[0.03]"
        style={{ backgroundImage: 'linear-gradient(#4f7ef8 1px, transparent 1px), linear-gradient(90deg, #4f7ef8 1px, transparent 1px)', backgroundSize: '40px 40px' }}
      />

      <div className="relative w-full max-w-sm animate-fade-in">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-9 h-9 rounded-xl bg-[#4f7ef8] flex items-center justify-center">
            <Zap size={18} className="text-white" />
          </div>
          <div>
            <h1 className="font-bold text-[#e8edf5] leading-none">SmartLeads</h1>
            <p className="text-xs text-[#8a97b0]">Lead management dashboard</p>
          </div>
        </div>

        <div className="bg-[#161b27] border border-[#2a3347] rounded-2xl p-6 shadow-2xl">
          <h2 className="text-lg font-semibold text-[#e8edf5] mb-1">Create account</h2>
          <p className="text-sm text-[#8a97b0] mb-6">Get started with SmartLeads</p>

          <form onSubmit={handleSubmit((d) => mutation.mutate(d))} className="space-y-4">
            <Input
              label="Full Name"
              placeholder="Rahul Sharma"
              icon={<User size={14} />}
              error={errors.name?.message}
              {...register('name')}
            />
            <Input
              label="Email"
              type="email"
              placeholder="you@example.com"
              icon={<Mail size={14} />}
              error={errors.email?.message}
              {...register('email')}
            />
            <Input
              label="Password"
              type="password"
              placeholder="Min 8 chars, A-z, 0-9"
              icon={<Lock size={14} />}
              error={errors.password?.message}
              {...register('password')}
            />

            {/* Role selector */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium text-[#8a97b0] uppercase tracking-wide">Role</label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { value: UserRole.SALES,  label: 'Sales',  desc: 'Manage own leads' },
                  { value: UserRole.ADMIN,  label: 'Admin',  desc: 'Full access' },
                ].map((r) => (
                  <label key={r.value} className="relative cursor-pointer">
                    <input type="radio" value={r.value} className="sr-only" {...register('role')} />
                    <div className="border border-[#2a3347] rounded-lg p-3 hover:border-[#4f7ef8]/50 transition-all text-center has-[:checked]:border-[#4f7ef8] has-[:checked]:bg-[rgba(79,126,248,0.08)]">
                      <p className="text-sm font-medium text-[#e8edf5]">{r.label}</p>
                      <p className="text-xs text-[#8a97b0]">{r.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <Button type="submit" className="w-full" loading={mutation.isPending} size="lg">
              Create account
            </Button>
          </form>

          <p className="text-center text-sm text-[#8a97b0] mt-5">
            Already have an account?{' '}
            <Link to="/signin" className="text-[#4f7ef8] hover:text-[#6b93ff] font-medium transition-colors">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default SignupPage;
