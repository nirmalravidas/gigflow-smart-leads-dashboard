import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { Zap, Mail, Lock } from 'lucide-react';
import { authApi } from '../../api/auth.api';
import { useAuthStore } from '../../store/auth.store';
import { Input } from '../../components/ui/FormFields';
import { Button } from '../../components/ui/Button';
import { getErrorMessage } from '../../utils/helpers';

const schema = z.object({
  email:    z.string().email('Invalid email'),
  password: z.string().min(1, 'Password required'),
});
type FormData = z.infer<typeof schema>;

const SigninPage: React.FC = () => {
  const navigate = useNavigate();
  const setAuth = useAuthStore((s) => s.setAuth);

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const mutation = useMutation({
    mutationFn: (data: FormData) => authApi.signin(data).then((r) => r.data.data!),
    onSuccess: ({ user, tokens }) => {
      setAuth(user, tokens);
      toast.success(`Welcome back, ${user.name.split(' ')[0]}!`);
      navigate('/dashboard');
    },
    onError: (err) => toast.error(getErrorMessage(err)),
  });

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0f1117] p-4">
      {/* Background grid */}
      <div className="absolute inset-0 opacity-[0.03]"
        style={{ backgroundImage: 'linear-gradient(#4f7ef8 1px, transparent 1px), linear-gradient(90deg, #4f7ef8 1px, transparent 1px)', backgroundSize: '40px 40px' }}
      />

      <div className="relative w-full max-w-sm animate-fade-in">
        {/* Logo */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-9 h-9 rounded-xl bg-[#4f7ef8] flex items-center justify-center">
            <Zap size={18} className="text-white" />
          </div>
          <div>
            <h1 className="font-bold text-[#e8edf5] leading-none">SmartLeads</h1>
            <p className="text-xs text-[#8a97b0]">Lead management dashboard</p>
          </div>
        </div>

        {/* Card */}
        <div className="bg-[#161b27] border border-[#2a3347] rounded-2xl p-6 shadow-2xl">
          <h2 className="text-lg font-semibold text-[#e8edf5] mb-1">Sign in</h2>
          <p className="text-sm text-[#8a97b0] mb-6">Enter your credentials to continue</p>

          <form onSubmit={handleSubmit((d) => mutation.mutate(d))} className="space-y-4">
            <Input
              label="Email"
              type="email"
              placeholder="you@example.com"
              icon={<Mail size={14} />}
              error={errors.email?.message}
              {...register('email')}
            />
            <Input
              label="Password"
              type="password"
              placeholder="••••••••"
              icon={<Lock size={14} />}
              error={errors.password?.message}
              {...register('password')}
            />

            <div className="flex justify-end">
              <Link to="/forgot-password" className="text-xs text-[#4f7ef8] hover:text-[#6b93ff] transition-colors">
                Forgot password?
              </Link>
            </div>

            <Button type="submit" className="w-full" loading={mutation.isPending} size="lg">
              Sign in
            </Button>
          </form>

          <p className="text-center text-sm text-[#8a97b0] mt-5">
            Don't have an account?{' '}
            <Link to="/signup" className="text-[#4f7ef8] hover:text-[#6b93ff] font-medium transition-colors">
              Sign up
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default SigninPage;
