import { useNavigate } from 'react-router-dom';
import {
  Activity,
  ArrowRight,
  Check,
  ChevronRight,
  Database,
  Download,
  Filter,
  Lock,
  Shield,
  Zap,
} from 'lucide-react';

const LandingPage = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: <Filter size={18} className="text-[#4f7ef8]" />,
      iconBg: 'bg-[rgba(79,126,248,0.12)]',
      title: 'Advanced filtering',
      desc: 'Filter by status, source, and search by name or email. Filters combine in one query.',
    },
    {
      icon: <Shield size={18} className="text-[#22c55e]" />,
      iconBg: 'bg-[rgba(34,197,94,0.1)]',
      title: 'Role-based access',
      desc: 'Admins see everything. Sales users only see their own leads — enforced server-side.',
    },
    {
      icon: <Download size={18} className="text-[#a855f7]" />,
      iconBg: 'bg-[rgba(168,85,247,0.1)]',
      title: 'CSV export',
      desc: 'Export any filtered view instantly. Great for reporting and follow-ups.',
    },
    {
      icon: <Lock size={18} className="text-[#f59e0b]" />,
      iconBg: 'bg-[rgba(245,158,11,0.1)]',
      title: 'JWT authentication',
      desc: 'Access + refresh token flow with email verification and secure password handling.',
    },
    {
      icon: <Database size={18} className="text-[#fb923c]" />,
      iconBg: 'bg-[rgba(251,146,60,0.1)]',
      title: 'Backend pagination',
      desc: 'Fast paging with total counts and page metadata for consistent navigation.',
    },
    {
      icon: <Activity size={18} className="text-[#f05252]" />,
      iconBg: 'bg-[rgba(240,82,82,0.1)]',
      title: 'Debounced search',
      desc: 'Search across name and email without hammering your API on every keystroke.',
    },
  ];

  return (
    <div className="min-h-screen bg-[#0a0d14] text-[#e2e8f0]">
      <nav className="sticky top-0 z-40 border-b border-[#1e2535] bg-[rgba(10,13,20,0.85)] backdrop-blur">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
          <button
            type="button"
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-2.5"
          >
            <span className="w-8 h-8 rounded-xl bg-[#4f7ef8] flex items-center justify-center">
              <Zap size={16} className="text-white" />
            </span>
            <span className="font-bold text-sm tracking-tight">SmartLeads</span>
          </button>

          <div className="hidden md:flex items-center gap-7 text-sm text-[#94a3b8]">
            <a href="#features" className="hover:text-[#e2e8f0] transition-colors">
              Features
            </a>
            <a href="#pricing" className="hover:text-[#e2e8f0] transition-colors">
              Pricing
            </a>
            <a href="#docs" className="hover:text-[#e2e8f0] transition-colors">
              Docs
            </a>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => navigate('/signin')}
              className="h-9 px-3.5 rounded-lg text-sm font-medium text-[#94a3b8] border border-[#2a3347] hover:bg-[#1e2535] hover:text-[#e2e8f0] transition-colors"
            >
              Sign in
            </button>
            <button
              type="button"
              onClick={() => navigate('/signup')}
              className="h-9 px-3.5 rounded-lg text-sm font-semibold bg-[#4f7ef8] hover:bg-[#6b93ff] text-white transition-colors"
            >
              Get started
            </button>
          </div>
        </div>
      </nav>

      <header className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 pt-14 sm:pt-20 pb-12 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-[#2a3347] bg-[#1e2535] px-4 py-1.5 text-xs text-[#94a3b8]">
          <Zap size={12} className="text-[#4f7ef8]" />
          <span className="text-[#4f7ef8] font-medium">v2.0 now live</span>
          <span className="hidden sm:inline">— Smarter lead scoring</span>
        </div>

        <h1 className="mt-6 text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight">
          Manage leads. <span className="text-[#4f7ef8]">Close deals faster.</span>
        </h1>

        <p className="mt-4 text-sm sm:text-base text-[#64748b] leading-relaxed max-w-xl mx-auto">
          SmartLeads gives your sales team a single place to track, filter, and convert leads — with role-based access,
          real-time search, and CSV exports built in.
        </p>

        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            type="button"
            onClick={() => navigate('/signup')}
            className="w-full sm:w-auto h-11 px-6 rounded-xl bg-[#4f7ef8] hover:bg-[#6b93ff] text-white font-semibold text-sm inline-flex items-center justify-center gap-2 transition-colors"
          >
            Start for free <ArrowRight size={16} />
          </button>
          <button
            type="button"
            onClick={() => navigate('/signin')}
            className="w-full sm:w-auto h-11 px-6 rounded-xl bg-[#111827] border border-[#2a3347] text-[#e2e8f0] font-medium text-sm inline-flex items-center justify-center gap-2 hover:bg-[#1e2535] transition-colors"
          >
            View demo <ChevronRight size={16} />
          </button>
        </div>
      </header>

      <section id="features" className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 pb-16">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">Everything your sales team needs</h2>
          <p className="mt-2 text-sm text-[#64748b]">
            Fast filters, role-based access, and exports that match your workflow.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((f) => (
            <div
              key={f.title}
              className="bg-[#111827] border border-[#1e2535] rounded-2xl p-6 hover:border-[#2a3347] transition-colors"
            >
              <div className={`w-10 h-10 rounded-xl ${f.iconBg} flex items-center justify-center mb-4`}>
                {f.icon}
              </div>
              <h3 className="text-sm font-semibold text-[#e2e8f0]">{f.title}</h3>
              <p className="mt-2 text-sm text-[#64748b] leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 pb-16">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">Trusted by sales teams</h2>
          <p className="mt-2 text-sm text-[#64748b]">A few words from teams using SmartLeads.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {
              quote: 'SmartLeads cut our response time to new leads by 60%. The filtering is incredibly fast.',
              name: 'Rahul Sharma',
              role: 'Sales Lead, Acme Corp',
              initials: 'RS',
              color: 'text-[#4f7ef8]',
              bg: 'bg-[rgba(79,126,248,0.15)]',
            },
            {
              quote: 'The role-based access is exactly what we needed. Sales reps only see their own pipeline.',
              name: 'Priya Verma',
              role: 'Head of Sales, TechCo',
              initials: 'PV',
              color: 'text-[#a855f7]',
              bg: 'bg-[rgba(168,85,247,0.15)]',
            },
            {
              quote: 'Onboarding took 2 minutes. CSV export with filters saved us hours of manual reporting.',
              name: 'Arjun Mehta',
              role: 'CRO, GrowthHQ',
              initials: 'AM',
              color: 'text-[#22c55e]',
              bg: 'bg-[rgba(34,197,94,0.12)]',
            },
          ].map((t) => (
            <div key={t.name} className="bg-[#111827] border border-[#1e2535] rounded-2xl p-6">
              <p className="text-sm text-[#94a3b8] leading-relaxed italic">"{t.quote}"</p>
              <div className="mt-5 flex items-center gap-3">
                <div className={`w-9 h-9 rounded-full ${t.bg} flex items-center justify-center text-xs font-semibold ${t.color}`}>
                  {t.initials}
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-[#e2e8f0] truncate">{t.name}</p>
                  <p className="text-xs text-[#64748b] truncate">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section id="pricing" className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 pb-16">
        <div className="bg-[#111827] border border-[#1e2535] rounded-3xl p-8 sm:p-12 text-center">
          <div className="w-12 h-12 rounded-2xl bg-[#4f7ef8] flex items-center justify-center mx-auto">
            <Zap size={22} className="text-white" />
          </div>
          <h2 className="mt-5 text-2xl sm:text-3xl font-bold tracking-tight">Ready to manage smarter?</h2>
          <p className="mt-2 text-sm text-[#64748b] max-w-xl mx-auto leading-relaxed">
            Create your account in seconds. No credit card required. Start tracking leads immediately.
          </p>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-sm text-[#94a3b8]">
            {['Free to start', 'Admin + Sales roles', 'JWT secure auth'].map((item) => (
              <div key={item} className="inline-flex items-center gap-2">
                <Check size={16} className="text-[#22c55e]" />
                {item}
              </div>
            ))}
          </div>

          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => navigate('/signup')}
              className="w-full sm:w-auto h-11 px-6 rounded-xl bg-[#4f7ef8] hover:bg-[#6b93ff] text-white font-semibold text-sm inline-flex items-center justify-center gap-2 transition-colors"
            >
              Create account <ArrowRight size={16} />
            </button>
            <button
              type="button"
              onClick={() => navigate('/signin')}
              className="w-full sm:w-auto h-11 px-6 rounded-xl border border-[#2a3347] text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-[#1e2535] font-medium text-sm transition-colors"
            >
              Sign in instead
            </button>
          </div>
        </div>
      </section>

      <footer id="docs" className="border-t border-[#1e2535]">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <span className="w-7 h-7 rounded-xl bg-[#4f7ef8] flex items-center justify-center">
              <Zap size={14} className="text-white" />
            </span>
            <span className="text-sm font-semibold text-[#e2e8f0]">SmartLeads</span>
          </div>

          <p className="text-xs text-[#64748b]">
            Built with Node.js · Express · MongoDB · React · TypeScript
          </p>

          <div className="flex items-center gap-4 text-xs text-[#64748b]">
            {['Privacy', 'Terms', 'Contact'].map((l) => (
              <button key={l} type="button" className="hover:text-[#e2e8f0] transition-colors">
                {l}
              </button>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;

