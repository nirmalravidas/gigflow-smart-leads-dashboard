import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Plus, Download } from 'lucide-react';
import toast from 'react-hot-toast';
import { leadsApi } from '../../api/leads.api';
import { useLeadsFilterStore } from '../../store/leads.store';
import { LeadsFilterBar } from '../../components/leads/LeadsFilterBar';
import { LeadsTable } from '../../components/leads/LeadsTable';
import { Modal } from '../../components/ui';
import { LeadForm } from '../../components/leads/LeadForm';
import { Button } from '../../components/ui/Button';
import { downloadBlob, getErrorMessage } from '../../utils/helpers';

const LeadsPage: React.FC = () => {
  const [createOpen, setCreateOpen] = useState(false);
  const { filters } = useLeadsFilterStore();

  const exportMutation = useMutation({
    mutationFn: () =>
      leadsApi.exportCSV({
        status: filters.status || undefined,
        source: filters.source || undefined,
        search: filters.search || undefined,
        sort: filters.sort,
      }).then((r) => r.data as Blob),
    onSuccess: (blob) => {
      downloadBlob(blob, `leads-export-${Date.now()}.csv`);
      toast.success('CSV downloaded');
    },
    onError: (err) => toast.error(getErrorMessage(err)),
  });

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-[#e8edf5]">Leads</h1>
          <p className="text-sm text-[#8a97b0] mt-0.5">Manage and track your leads</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="sm"
            icon={<Download size={14} />}
            loading={exportMutation.isPending}
            onClick={() => exportMutation.mutate()}
          >
            Export CSV
          </Button>
          <Button
            size="sm"
            icon={<Plus size={14} />}
            onClick={() => setCreateOpen(true)}
          >
            New Lead
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="mb-5">
        <LeadsFilterBar />
      </div>

      {/* Table */}
      <LeadsTable />

      {/* Create Modal */}
      <Modal open={createOpen} onClose={() => setCreateOpen(false)} title="New Lead">
        <LeadForm onSuccess={() => setCreateOpen(false)} />
      </Modal>
    </div>
  );
};

export default LeadsPage;
