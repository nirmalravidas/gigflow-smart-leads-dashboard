import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Users, TrendingUp, UserCheck, UserX, BarChart3 } from 'lucide-react';
import { leadsApi } from '../../api/leads.api';
import { useAuthStore } from '../../store/auth.store';
import { LeadStatus, LeadSource } from '../../types';
import { PageLoader } from '../../components/ui';

const StatCard: React.FC<{
  title: string;
  value: number | string;
  icon: React.ReactNode;
  color: string;
  sub?: string;
}> = ({ title, value, icon, color, sub }) => (
  <div className="bg-[#161b27] border border-[#2a3347] rounded-xl p-5 animate-fade-in">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-xs text-[#8a97b0] uppercase tracking-wide font-medium">{title}</p>
        <p className="text-3xl font-bold text-[#e8edf5] mt-1">{value}</p>
        {sub && <p className="text-xs text-[#8a97b0] mt-1">{sub}</p>}
      </div>
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}>
        {icon}
      </div>
    </div>
  </div>
);

const DashboardPage: React.FC = () => {
  const { user } = useAuthStore();

  const { data: statsData, isLoading } = useQuery({
    queryKey: ['stats'],
    queryFn: () => leadsApi.getStats().then((r) => r.data.data!),
  });

  const stats = statsData;

  return (
    <div className="p-6 max-w-6xl">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-[#e8edf5]">
          Good {getGreeting()}, {user?.name.split(' ')[0]} 👋
        </h1>
        <p className="text-sm text-[#8a97b0] mt-1">Here's what's happening with your leads</p>
      </div>

      {isLoading ? <PageLoader /> : (
        <>
          {/* Top stat cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <StatCard
              title="Total Leads"
              value={stats?.total ?? 0}
              icon={<Users size={18} className="text-[#4f7ef8]" />}
              color="bg-[rgba(79,126,248,0.12)]"
            />
            <StatCard
              title="Qualified"
              value={stats?.byStatus?.[LeadStatus.QUALIFIED] ?? 0}
              icon={<TrendingUp size={18} className="text-[#22c55e]" />}
              color="bg-[rgba(34,197,94,0.12)]"
              sub={`${pct(stats?.byStatus?.[LeadStatus.QUALIFIED], stats?.total)}% of total`}
            />
            <StatCard
              title="Contacted"
              value={stats?.byStatus?.[LeadStatus.CONTACTED] ?? 0}
              icon={<UserCheck size={18} className="text-[#f59e0b]" />}
              color="bg-[rgba(245,158,11,0.12)]"
            />
            <StatCard
              title="Lost"
              value={stats?.byStatus?.[LeadStatus.LOST] ?? 0}
              icon={<UserX size={18} className="text-[#f05252]" />}
              color="bg-[rgba(240,82,82,0.12)]"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* By Status */}
            <div className="bg-[#161b27] border border-[#2a3347] rounded-xl p-5">
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 size={16} className="text-[#4f7ef8]" />
                <h2 className="font-semibold text-[#e8edf5]">Leads by Status</h2>
              </div>
              <div className="space-y-3">
                {Object.entries(statusConfig).map(([status, cfg]) => {
                  const count = stats?.byStatus?.[status] ?? 0;
                  const total = stats?.total ?? 1;
                  const width = total > 0 ? (count / total) * 100 : 0;
                  return (
                    <div key={status}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-[#8a97b0]">{status}</span>
                        <span className="text-[#e8edf5] font-medium">{count}</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-[#1e2535]">
                        <div
                          className="h-1.5 rounded-full transition-all duration-500"
                          style={{ width: `${width}%`, background: cfg.color }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* By Source */}
            <div className="bg-[#161b27] border border-[#2a3347] rounded-xl p-5">
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 size={16} className="text-[#4f7ef8]" />
                <h2 className="font-semibold text-[#e8edf5]">Leads by Source</h2>
              </div>
              <div className="space-y-3">
                {Object.entries(sourceConfig).map(([source, cfg]) => {
                  const count = stats?.bySource?.[source] ?? 0;
                  const total = stats?.total ?? 1;
                  const width = total > 0 ? (count / total) * 100 : 0;
                  return (
                    <div key={source}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-[#8a97b0]">{source}</span>
                        <span className="text-[#e8edf5] font-medium">{count}</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-[#1e2535]">
                        <div
                          className="h-1.5 rounded-full transition-all duration-500"
                          style={{ width: `${width}%`, background: cfg.color }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

const getGreeting = () => {
  const h = new Date().getHours();
  if (h < 12) return 'morning';
  if (h < 17) return 'afternoon';
  return 'evening';
};

const pct = (val?: number, total?: number) => {
  if (!val || !total) return 0;
  return Math.round((val / total) * 100);
};

const statusConfig: Record<string, { color: string }> = {
  [LeadStatus.NEW]:       { color: '#4f7ef8' },
  [LeadStatus.CONTACTED]: { color: '#f59e0b' },
  [LeadStatus.QUALIFIED]: { color: '#22c55e' },
  [LeadStatus.LOST]:      { color: '#f05252' },
};

const sourceConfig: Record<string, { color: string }> = {
  [LeadSource.WEBSITE]:   { color: '#8a97b0' },
  [LeadSource.INSTAGRAM]: { color: '#a855f7' },
  [LeadSource.REFERRAL]:  { color: '#fb923c' },
};

export default DashboardPage;
