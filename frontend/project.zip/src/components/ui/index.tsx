import React from 'react';
import { X } from 'lucide-react';
import { LeadStatus, LeadSource } from '../../types';

// ─── Status Badge ─────────────────────────────────────────────────────────────

const statusConfig: Record<LeadStatus, { label: string; color: string }> = {
  [LeadStatus.NEW]:       { label: 'New',       color: 'bg-[rgba(79,126,248,0.15)] text-[#4f7ef8] border border-[rgba(79,126,248,0.3)]' },
  [LeadStatus.CONTACTED]: { label: 'Contacted',  color: 'bg-[rgba(245,158,11,0.12)] text-[#f59e0b] border border-[rgba(245,158,11,0.25)]' },
  [LeadStatus.QUALIFIED]: { label: 'Qualified',  color: 'bg-[rgba(34,197,94,0.12)] text-[#22c55e] border border-[rgba(34,197,94,0.25)]' },
  [LeadStatus.LOST]:      { label: 'Lost',       color: 'bg-[rgba(240,82,82,0.12)] text-[#f05252] border border-[rgba(240,82,82,0.25)]' },
};

const sourceConfig: Record<LeadSource, { label: string; color: string }> = {
  [LeadSource.WEBSITE]:   { label: 'Website',   color: 'bg-[#1e2535] text-[#8a97b0] border border-[#2a3347]' },
  [LeadSource.INSTAGRAM]: { label: 'Instagram', color: 'bg-[rgba(168,85,247,0.12)] text-[#a855f7] border border-[rgba(168,85,247,0.25)]' },
  [LeadSource.REFERRAL]:  { label: 'Referral',  color: 'bg-[rgba(251,146,60,0.12)] text-[#fb923c] border border-[rgba(251,146,60,0.25)]' },
};

export const StatusBadge: React.FC<{ status: LeadStatus }> = ({ status }) => {
  const cfg = statusConfig[status];
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium ${cfg.color}`}>
      {cfg.label}
    </span>
  );
};

export const SourceBadge: React.FC<{ source: LeadSource }> = ({ source }) => {
  const cfg = sourceConfig[source];
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium ${cfg.color}`}>
      {cfg.label}
    </span>
  );
};

// ─── Spinner ──────────────────────────────────────────────────────────────────

export const Spinner: React.FC<{ size?: number; className?: string }> = ({
  size = 20,
  className = '',
}) => (
  <div
    className={`rounded-full border-2 border-[#2a3347] border-t-[#4f7ef8] animate-spin ${className}`}
    style={{ width: size, height: size }}
  />
);

// ─── Full Page Loader ─────────────────────────────────────────────────────────

export const PageLoader: React.FC = () => (
  <div className="flex items-center justify-center h-64">
    <Spinner size={32} />
  </div>
);

// ─── Empty State ──────────────────────────────────────────────────────────────

interface EmptyStateProps {
  icon: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}

export const EmptyState: React.FC<EmptyStateProps> = ({ icon, title, description, action }) => (
  <div className="flex flex-col items-center justify-center py-16 gap-4">
    <div className="text-[#2a3347] w-12 h-12">{icon}</div>
    <div className="text-center">
      <p className="text-[#e8edf5] font-medium">{title}</p>
      {description && <p className="text-sm text-[#8a97b0] mt-1">{description}</p>}
    </div>
    {action}
  </div>
);

// ─── Modal ────────────────────────────────────────────────────────────────────

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  width?: string;
}

export const Modal: React.FC<ModalProps> = ({ open, onClose, title, children, width = 'max-w-lg' }) => {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className={`bg-[#161b27] border border-[#2a3347] rounded-xl w-full ${width} animate-fade-in shadow-2xl`}>
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#2a3347]">
          <h2 className="font-semibold text-[#e8edf5]">{title}</h2>
          <button
            onClick={onClose}
            className="text-[#8a97b0] hover:text-[#e8edf5] transition-colors p-1 rounded-md hover:bg-[#1e2535]"
          >
            <X size={16} />
          </button>
        </div>
        {/* Body */}
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
};

// ─── Confirm Dialog ───────────────────────────────────────────────────────────

interface ConfirmDialogProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  loading?: boolean;
}

export const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
  open, onClose, onConfirm, title, description, loading,
}) => {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)' }}
    >
      <div className="bg-[#161b27] border border-[#2a3347] rounded-xl w-full max-w-sm animate-fade-in shadow-2xl">
        <div className="p-5">
          <h2 className="font-semibold text-[#e8edf5] mb-2">{title}</h2>
          <p className="text-sm text-[#8a97b0]">{description}</p>
          <div className="flex gap-3 mt-5 justify-end">
            <button
              onClick={onClose}
              className="px-4 h-9 rounded-lg text-sm text-[#8a97b0] hover:text-[#e8edf5] hover:bg-[#1e2535] transition-all"
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              disabled={loading}
              className="px-4 h-9 rounded-lg text-sm bg-[rgba(240,82,82,0.12)] text-[#f05252] border border-[rgba(240,82,82,0.3)] hover:bg-[rgba(240,82,82,0.2)] transition-all disabled:opacity-50"
            >
              {loading ? 'Deleting...' : 'Delete'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
