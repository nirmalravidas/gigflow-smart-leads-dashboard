import React from 'react';

// ─── Input ────────────────────────────────────────────────────────────────────

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  icon?: React.ReactNode;
}

export const Input: React.FC<InputProps> = ({ label, error, icon, className = '', ...props }) => (
  <div className="flex flex-col gap-1.5">
    {label && (
      <label className="text-xs font-medium text-[#8a97b0] uppercase tracking-wide">
        {label}
      </label>
    )}
    <div className="relative">
      {icon && (
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8a97b0]">
          {icon}
        </span>
      )}
      <input
        className={`
          w-full h-9 rounded-lg border text-sm text-[#e8edf5] placeholder-[#4a5568]
          bg-[#161b27] border-[#2a3347] px-3
          focus:outline-none focus:border-[#4f7ef8] focus:ring-1 focus:ring-[#4f7ef8]/30
          transition-all duration-150
          disabled:opacity-50 disabled:cursor-not-allowed
          ${icon ? 'pl-9' : ''}
          ${error ? 'border-[#f05252] focus:border-[#f05252] focus:ring-[#f05252]/20' : ''}
          ${className}
        `}
        {...props}
      />
    </div>
    {error && <span className="text-xs text-[#f05252]">{error}</span>}
  </div>
);

// ─── Select ───────────────────────────────────────────────────────────────────

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  options: Array<{ value: string; label: string }>;
  placeholder?: string;
}

export const Select: React.FC<SelectProps> = ({
  label,
  error,
  options,
  placeholder,
  className = '',
  ...props
}) => (
  <div className="flex flex-col gap-1.5">
    {label && (
      <label className="text-xs font-medium text-[#8a97b0] uppercase tracking-wide">
        {label}
      </label>
    )}
    <select
      className={`
        w-full h-9 rounded-lg border text-sm text-[#e8edf5]
        bg-[#161b27] border-[#2a3347] px-3
        focus:outline-none focus:border-[#4f7ef8] focus:ring-1 focus:ring-[#4f7ef8]/30
        transition-all duration-150 cursor-pointer
        disabled:opacity-50 disabled:cursor-not-allowed
        ${error ? 'border-[#f05252]' : ''}
        ${className}
      `}
      {...props}
    >
      {placeholder && <option value="">{placeholder}</option>}
      {options.map((o) => (
        <option key={o.value} value={o.value}>{o.label}</option>
      ))}
    </select>
    {error && <span className="text-xs text-[#f05252]">{error}</span>}
  </div>
);

// ─── Textarea ─────────────────────────────────────────────────────────────────

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
}

export const Textarea: React.FC<TextareaProps> = ({ label, error, className = '', ...props }) => (
  <div className="flex flex-col gap-1.5">
    {label && (
      <label className="text-xs font-medium text-[#8a97b0] uppercase tracking-wide">
        {label}
      </label>
    )}
    <textarea
      className={`
        w-full rounded-lg border text-sm text-[#e8edf5] placeholder-[#4a5568]
        bg-[#161b27] border-[#2a3347] px-3 py-2.5 resize-none
        focus:outline-none focus:border-[#4f7ef8] focus:ring-1 focus:ring-[#4f7ef8]/30
        transition-all duration-150
        ${error ? 'border-[#f05252]' : ''}
        ${className}
      `}
      rows={3}
      {...props}
    />
    {error && <span className="text-xs text-[#f05252]">{error}</span>}
  </div>
);
