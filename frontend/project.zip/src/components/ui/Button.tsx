import React from 'react';
import { Loader2 } from 'lucide-react';

type Variant = 'primary' | 'secondary' | 'danger' | 'ghost';
type Size    = 'sm' | 'md' | 'lg';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  icon?: React.ReactNode;
}

const variantStyles: Record<Variant, string> = {
  primary:   'bg-[#4f7ef8] hover:bg-[#6b93ff] text-white border border-[#4f7ef8]',
  secondary: 'bg-[#1e2535] hover:bg-[#2a3347] text-[#e8edf5] border border-[#2a3347]',
  danger:    'bg-[rgba(240,82,82,0.12)] hover:bg-[rgba(240,82,82,0.2)] text-[#f05252] border border-[rgba(240,82,82,0.3)]',
  ghost:     'bg-transparent hover:bg-[#1e2535] text-[#8a97b0] hover:text-[#e8edf5] border border-transparent',
};

const sizeStyles: Record<Size, string> = {
  sm: 'h-7 px-3 text-xs gap-1.5',
  md: 'h-9 px-4 text-sm gap-2',
  lg: 'h-11 px-5 text-sm gap-2',
};

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  loading = false,
  icon,
  children,
  disabled,
  className = '',
  ...props
}) => (
  <button
    disabled={disabled || loading}
    className={`
      inline-flex items-center justify-center font-medium rounded-lg
      transition-all duration-150 cursor-pointer select-none
      disabled:opacity-50 disabled:cursor-not-allowed
      ${variantStyles[variant]} ${sizeStyles[size]} ${className}
    `}
    {...props}
  >
    {loading ? <Loader2 className="animate-spin" size={14} /> : icon}
    {children}
  </button>
);
