import React, { useMemo } from 'react';
import { Search, X, RotateCcw, Filter } from 'lucide-react';
import { useLeadsFilterStore } from '../../store/leads.store';
import { LeadStatus, LeadSource, SortOrder } from '../../types';
import { Button } from '../ui/Button';

const STATUS_OPTIONS = [
  { value: '', label: 'All Statuses' },
  ...Object.values(LeadStatus).map((value) => ({
    value,
    label: value,
  })),
];

const SOURCE_OPTIONS = [
  { value: '', label: 'All Sources' },
  ...Object.values(LeadSource).map((value) => ({
    value,
    label: value,
  })),
];

const SORT_OPTIONS = [
  {
    value: SortOrder.LATEST,
    label: 'Latest first',
  },
  {
    value: SortOrder.OLDEST,
    label: 'Oldest first',
  },
];

export const LeadsFilterBar: React.FC = () => {
  const {
    filters,
    draft,
    setDraftFilter,
    setDraftSearch,
    applyFilters,
    resetFilters,
  } = useLeadsFilterStore();

  const hasActiveFilters =
    !!filters.status ||
    !!filters.source ||
    !!filters.search ||
    filters.sort !== SortOrder.LATEST;

  const isDirty = useMemo(() => {
    return (
      (draft.status ?? '') !== (filters.status ?? '') ||
      (draft.source ?? '') !== (filters.source ?? '') ||
      (draft.search ?? '') !== (filters.search ?? '') ||
      (draft.sort ?? SortOrder.LATEST) !==
        (filters.sort ?? SortOrder.LATEST)
    );
  }, [draft, filters]);

  return (
    <div className="rounded-3xl border border-(--border) bg-(--surface) shadow-sm">
      <div className="flex flex-col gap-4 p-4 md:p-5">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="text-base font-semibold text-(--text)">
              Filter Leads
            </h2>
            <p className="text-sm text-(--text-muted)">
              Search, segment, and sort your pipeline faster
            </p>
          </div>

          {hasActiveFilters && (
            <div className="inline-flex items-center gap-2 rounded-2xl bg-(--primary-soft) px-3 py-2 text-xs font-medium text-(--primary)">
              <span className="w-2 h-2 rounded-full bg-(--primary)" />
              Active filters applied
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-5">
          <div className="relative xl:col-span-2">
            <Search
              size={16}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-(--text-muted)"
            />

            <input
              value={draft.search ?? ''}
              onChange={(e) => setDraftSearch(e.target.value)}
              placeholder="Search by lead name or email..."
              className="h-12 w-full rounded-2xl border border-(--border) bg-(--surface-2) pl-11 pr-11 text-sm text-(--text) placeholder:text-(--text-soft) outline-none transition-all focus:border-(--primary) focus:ring-4 focus:ring-(--primary-soft)"
            />

            {draft.search && (
              <button
                type="button"
                onClick={() => setDraftSearch('')}
                className="absolute right-3 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-xl text-(--text-muted) transition hover:bg-(--surface) hover:text-(--text)"
              >
                <X size={14} />
              </button>
            )}
          </div>

          <select
            value={draft.status ?? ''}
            onChange={(e) =>
              setDraftFilter(
                'status',
                e.target.value as LeadStatus | ''
              )
            }
            className="h-12 rounded-2xl border border-(--border) bg-(--surface-2) px-4 text-sm text-(--text) outline-none transition-all focus:border-(--primary) focus:ring-4 focus:ring-(--primary-soft)"
          >
            {STATUS_OPTIONS.map((option) => (
              <option
                key={option.value}
                value={option.value}
              >
                {option.label}
              </option>
            ))}
          </select>

          <select
            value={draft.source ?? ''}
            onChange={(e) =>
              setDraftFilter(
                'source',
                e.target.value as LeadSource | ''
              )
            }
            className="h-12 rounded-2xl border border-(--border) bg-(--surface-2) px-4 text-sm text-(--text) outline-none transition-all focus:border-(--primary) focus:ring-4 focus:ring-(--primary-soft)"
          >
            {SOURCE_OPTIONS.map((option) => (
              <option
                key={option.value}
                value={option.value}
              >
                {option.label}
              </option>
            ))}
          </select>

          <select
            value={draft.sort ?? SortOrder.LATEST}
            onChange={(e) =>
              setDraftFilter(
                'sort',
                e.target.value as SortOrder
              )
            }
            className="h-12 rounded-2xl border border-(--border) bg-(--surface-2) px-4 text-sm text-(--text) outline-none transition-all focus:border-(--primary) focus:ring-4 focus:ring-(--primary-soft)"
          >
            {SORT_OPTIONS.map((option) => (
              <option
                key={option.value}
                value={option.value}
              >
                {option.label}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-3 pt-1 sm:flex-row sm:items-center sm:justify-end">
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="md"
              icon={<RotateCcw size={15} />}
              onClick={resetFilters}
              className="w-full sm:w-auto"
            >
              Reset filters
            </Button>
          )}

          <Button
            size="md"
            icon={<Filter size={15} />}
            disabled={!isDirty}
            onClick={applyFilters}
            className="w-full sm:w-auto"
          >
            Apply filters
          </Button>
        </div>
      </div>
    </div>
  );
};