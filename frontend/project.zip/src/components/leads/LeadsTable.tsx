import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Pencil, Trash2, UserCircle, ChevronLeft, ChevronRight, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import { leadsApi } from '../../api/leads.api';
import type { ILead } from '../../types';
import { UserRole } from '../../types';
import { useLeadsFilterStore } from '../../store/leads.store';
import { useAuthStore } from '../../store/auth.store';
import { StatusBadge, SourceBadge, PageLoader, EmptyState, ConfirmDialog } from '../ui';
import { Button } from '../ui/Button';
import { Modal } from '../ui';
import { LeadForm } from './LeadForm';
import { getErrorMessage } from '../../utils/helpers';

export const LeadsTable: React.FC = () => {
  const { filters, debouncedSearch, setPage } = useLeadsFilterStore();
  const { user } = useAuthStore();
  const qc = useQueryClient();
  const isAdmin = user?.role === UserRole.ADMIN;

  const [editLead, setEditLead] = useState<ILead | null>(null);
  const [deleteLead, setDeleteLead] = useState<ILead | null>(null);

  // Build query with applied filters + applied search
  const queryFilters = { ...filters, search: debouncedSearch || undefined };

  const { data, isLoading, isError } = useQuery({
    queryKey: ['leads', queryFilters],
    queryFn: () => leadsApi.getLeads(queryFilters).then((r) => r.data.data!),
    placeholderData: (prev) => prev,
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => leadsApi.deleteLead(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['leads'] });
      qc.invalidateQueries({ queryKey: ['stats'] });
      toast.success('Lead deleted');
      setDeleteLead(null);
    },
    onError: (err) => toast.error(getErrorMessage(err)),
  });

  if (isLoading) return <PageLoader />;

  if (isError) return (
    <div className="flex items-center gap-2 text-[#f05252] p-4">
      <AlertCircle size={16} />
      <span className="text-sm">Failed to load leads</span>
    </div>
  );

  const leads = data?.data ?? [];
  const meta  = data?.meta;

  return (
    <>
      {/* Table */}
      <div className="border border-[#2a3347] rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[#2a3347] bg-[#161b27]">
              {['Lead', 'Status', 'Source', 'Created by', 'Date', 'Actions'].map((h) => (
                <th key={h} className="px-4 py-3 text-left text-xs font-medium text-[#8a97b0] uppercase tracking-wide">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1e2535]">
            {leads.length === 0 ? (
              <tr>
                <td colSpan={6}>
                  <EmptyState
                    icon={<UserCircle size={48} />}
                    title="No leads found"
                    description="Try adjusting your filters or create a new lead."
                  />
                </td>
              </tr>
            ) : (
              leads.map((lead, i) => (
                <tr
                  key={lead._id}
                  className="hover:bg-[#161b27] transition-colors animate-fade-in"
                  style={{ animationDelay: `${i * 30}ms` }}
                >
                  {/* Lead info */}
                  <td className="px-4 py-3">
                    <div>
                      <p className="font-medium text-[#e8edf5]">{lead.name}</p>
                      <p className="text-xs text-[#8a97b0]">{lead.email}</p>
                    </div>
                  </td>
                  {/* Status */}
                  <td className="px-4 py-3">
                    <StatusBadge status={lead.status} />
                  </td>
                  {/* Source */}
                  <td className="px-4 py-3">
                    <SourceBadge source={lead.source} />
                  </td>
                  {/* Created by */}
                  <td className="px-4 py-3 text-sm text-[#8a97b0]">
                    {lead.createdBy?.name ?? '—'}
                  </td>
                  {/* Date */}
                  <td className="px-4 py-3 text-xs text-[#8a97b0] mono">
                    {new Date(lead.createdAt).toLocaleDateString('en-IN', {
                      day: '2-digit', month: 'short', year: 'numeric',
                    })}
                  </td>
                  {/* Actions */}
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        icon={<Pencil size={13} />}
                        onClick={() => setEditLead(lead)}
                      />
                      {isAdmin && (
                        <Button
                          variant="danger"
                          size="sm"
                          icon={<Trash2 size={13} />}
                          onClick={() => setDeleteLead(lead)}
                        />
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {meta && meta.totalPages > 1 && (
        <div className="flex items-center justify-between mt-4">
          <p className="text-xs text-[#8a97b0]">
            Showing {((meta.page - 1) * meta.limit) + 1}–{Math.min(meta.page * meta.limit, meta.total)} of {meta.total} leads
          </p>
          <div className="flex items-center gap-1">
            <Button
              variant="secondary"
              size="sm"
              icon={<ChevronLeft size={14} />}
              disabled={!meta.hasPrevPage}
              onClick={() => setPage(meta.page - 1)}
            />
            {Array.from({ length: meta.totalPages }, (_, i) => i + 1)
              .filter((p) => Math.abs(p - meta.page) <= 2)
              .map((p) => (
                <button
                  key={p}
                  onClick={() => setPage(p)}
                  className={`w-8 h-8 rounded-lg text-sm font-medium transition-all ${
                    p === meta.page
                      ? 'bg-[#4f7ef8] text-white'
                      : 'text-[#8a97b0] hover:text-[#e8edf5] hover:bg-[#1e2535]'
                  }`}
                >
                  {p}
                </button>
              ))}
            <Button
              variant="secondary"
              size="sm"
              icon={<ChevronRight size={14} />}
              disabled={!meta.hasNextPage}
              onClick={() => setPage(meta.page + 1)}
            />
          </div>
        </div>
      )}

      {/* Edit Modal */}
      <Modal
        open={!!editLead}
        onClose={() => setEditLead(null)}
        title="Edit Lead"
      >
        {editLead && (
          <LeadForm lead={editLead} onSuccess={() => setEditLead(null)} />
        )}
      </Modal>

      {/* Delete Confirm */}
      <ConfirmDialog
        open={!!deleteLead}
        onClose={() => setDeleteLead(null)}
        onConfirm={() => deleteLead && deleteMutation.mutate(deleteLead._id)}
        loading={deleteMutation.isPending}
        title="Delete Lead"
        description={`Are you sure you want to delete "${deleteLead?.name}"? This cannot be undone.`}
      />
    </>
  );
};
