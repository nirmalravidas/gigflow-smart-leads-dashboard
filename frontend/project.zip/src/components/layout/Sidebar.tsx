import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Users, LogOut, ChevronLeft, ChevronRight,
  Zap, UserCircle, Shield, UserCheck, X,
} from 'lucide-react';
import { useAuthStore } from '../../store/auth.store';
import { authApi } from '../../api/auth.api';
import { UserRole } from '../../types';
import { useState } from 'react';

interface NavItem {
  to: string;
  icon: React.ReactNode;
  label: string;
  adminOnly?: boolean;
}

const navItems: NavItem[] = [
  { to: '/dashboard', icon: <LayoutDashboard size={18} />, label: 'Dashboard' },
  { to: '/leads',     icon: <UserCheck size={18} />,       label: 'Leads' },
  { to: '/users',     icon: <Users size={18} />,           label: 'Users', adminOnly: true },
];

export const Sidebar = ({
  mobileOpen = false,
  onMobileClose,
}: {
  mobileOpen?: boolean;
  onMobileClose?: () => void;
}) => {
  const [collapsed, setCollapsed] = useState(false);
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try { await authApi.signout(); } catch { /* swallow */ }
    finally { logout(); navigate('/signin'); }
  };

  const items = navItems.filter((i) => !i.adminOnly || user?.role === UserRole.ADMIN);

  return (
    <>
      {/* Mobile backdrop */}
      <div
        className={`fixed inset-0 z-40 bg-black/50 transition-opacity md:hidden ${
          mobileOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onMobileClose}
      />

      <aside
        className={[
          'fixed z-50 inset-y-0 left-0 flex flex-col border-r border-[#2a3347] bg-[#161b27] transition-transform duration-200 shrink-0',
          mobileOpen ? 'translate-x-0' : '-translate-x-full',
          'md:static md:translate-x-0',
          collapsed ? 'w-[60px]' : 'w-[220px]',
        ].join(' ')}
      >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 h-14 border-b border-[#2a3347]">
        <div className="w-7 h-7 rounded-lg bg-[#4f7ef8] flex items-center justify-center shrink-0">
          <Zap size={14} className="text-white" />
        </div>
        {!collapsed && (
          <span className="font-bold text-[#e8edf5] text-sm tracking-tight">SmartLeads</span>
        )}

        <div className="ml-auto md:hidden">
          <button
            type="button"
            onClick={onMobileClose}
            className="inline-flex items-center justify-center w-9 h-9 rounded-lg text-[#8a97b0] hover:text-[#e8edf5] hover:bg-[#1e2535] transition-colors"
            aria-label="Close navigation"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 flex flex-col gap-0.5 p-2 pt-3 overflow-y-auto">
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            title={collapsed ? item.label : undefined}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 h-9 rounded-lg text-sm font-medium transition-all duration-150 ${
                isActive
                  ? 'bg-[rgba(79,126,248,0.15)] text-[#4f7ef8]'
                  : 'text-[#8a97b0] hover:text-[#e8edf5] hover:bg-[#1e2535]'
              }`
            }
          >
            <span className="shrink-0">{item.icon}</span>
            {!collapsed && <span className="truncate">{item.label}</span>}
          </NavLink>
        ))}
      </nav>

      {/* Footer */}
      <div className="border-t border-[#2a3347] p-2 space-y-1">
        {/* Profile link */}
        <NavLink
          to="/profile"
          title={collapsed ? 'Profile' : undefined}
          className={({ isActive }) =>
            `flex items-center gap-2.5 w-full px-3 py-2 rounded-lg transition-all ${
              isActive ? 'bg-[rgba(79,126,248,0.1)]' : 'hover:bg-[#1e2535]'
            }`
          }
        >
          <div className="w-7 h-7 rounded-full bg-[#4f7ef8]/20 flex items-center justify-center shrink-0">
            {user?.role === UserRole.ADMIN
              ? <Shield size={13} className="text-[#4f7ef8]" />
              : <UserCircle size={13} className="text-[#8a97b0]" />
            }
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-[#e8edf5] truncate">{user?.name}</p>
              <p className="text-[10px] text-[#8a97b0] capitalize">{user?.role}</p>
            </div>
          )}
        </NavLink>

        <button
          onClick={handleLogout}
          title={collapsed ? 'Sign out' : undefined}
          className="flex items-center gap-3 w-full px-3 h-9 rounded-lg text-sm text-[#8a97b0] hover:text-[#f05252] hover:bg-[rgba(240,82,82,0.08)] transition-all duration-150"
        >
          <LogOut size={16} className="shrink-0" />
          {!collapsed && 'Sign out'}
        </button>

        <button
          onClick={() => setCollapsed((p) => !p)}
          title={collapsed ? 'Expand' : 'Collapse'}
          className="hidden md:flex items-center gap-3 w-full px-3 h-9 rounded-lg text-sm text-[#8a97b0] hover:text-[#e8edf5] hover:bg-[#1e2535] transition-all duration-150"
        >
          {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          {!collapsed && 'Collapse'}
        </button>
      </div>
    </aside>
    </>
  );
};
