import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { Menu } from 'lucide-react';

export const AppLayout: React.FC = () => {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  return (
    <div className="flex h-screen overflow-hidden bg-[#0f1117]">
      <Sidebar
        mobileOpen={mobileSidebarOpen}
        onMobileClose={() => setMobileSidebarOpen(false)}
      />

      <div className="flex-1 min-w-0 flex flex-col">
        {/* Mobile header */}
        <header className="md:hidden h-14 border-b border-[#2a3347] bg-[#161b27] flex items-center px-4">
          <button
            type="button"
            onClick={() => setMobileSidebarOpen(true)}
            className="inline-flex items-center justify-center w-9 h-9 rounded-lg text-[#8a97b0] hover:text-[#e8edf5] hover:bg-[#1e2535] transition-colors"
            aria-label="Open navigation"
          >
            <Menu size={18} />
          </button>
          <div className="ml-3">
            <p className="text-sm font-semibold text-[#e8edf5] leading-none">SmartLeads</p>
            <p className="text-[11px] text-[#8a97b0] mt-0.5">Leads dashboard</p>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto min-w-0">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
